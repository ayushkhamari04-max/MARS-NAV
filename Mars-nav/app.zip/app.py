import streamlit.components.v1 as components
import streamlit as st
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import folium
from streamlit_folium import st_folium
from io import BytesIO
import rasterio


@st.cache_data(show_spinner="Loading Jezero terrain...")
def load_rover_terrain(dem_path, stride=20):
    with rasterio.open(dem_path) as src:
        elevation = src.read(
            1,
            out_shape=(
                max(1, src.height // stride),
                max(1, src.width // stride)
            ),
            resampling=rasterio.enums.Resampling.average
        ).astype(np.float32)

        nodata = src.nodata
        pixel_size = abs(src.transform.a) * stride

    if nodata is not None:
        elevation[elevation == nodata] = np.nan

    valid = np.isfinite(elevation)

    if not valid.any():
        raise ValueError("The DEM contains no valid elevation data.")

    filled = np.where(
        valid,
        elevation,
        np.nanmedian(elevation)
    )

    dz_dy, dz_dx = np.gradient(
        filled,
        pixel_size,
        pixel_size
    )

    slope = np.degrees(
        np.arctan(np.sqrt(dz_dx**2 + dz_dy**2))
    )

    return elevation, slope, pixel_size


# ============================================================
# MARS-NAV | MARTIAN EXPLORATION AND NAVIGATION SYSTEM
# ============================================================

st.set_page_config(
    page_title="MARS-NAV | Martian Mission Control",
    page_icon="🔴",
    layout="wide",
    initial_sidebar_state="expanded"
)

# -------------------- DESIGN --------------------

st.markdown("""
<style>
.stApp {
    background: linear-gradient(135deg, #100c0b, #21100e);
    color: #f5e6d6;
}
h1, h2, h3 {
    color: #ff9b62 !important;
}
[data-testid="stSidebar"] {
    background: #100d0c;
    border-right: 1px solid #9b4932;
}
div[data-testid="stMetric"] {
    background: #271511;
    border: 1px solid #9b4932;
    padding: 14px;
    border-radius: 12px;
}
.stButton button {
    background: #a83d28;
    color: white;
    border-radius: 8px;
    border: 1px solid #ff9b62;
}
</style>
""", unsafe_allow_html=True)

# -------------------- CONSTANTS --------------------

MARS_RADIUS_KM = 3389.5

JEZERO_LAT = 18.44
JEZERO_LON = 77.73

# Approximate educational reference locations.
LANDMARKS = {
    "Jezero Crater Centre": (18.44, 77.73),
    "Western Delta Region": (18.45, 77.55),
    "Eastern Rim": (18.42, 77.91),
    "Northern Region": (18.60, 77.73),
    "Southern Region": (18.27, 77.73)
}

# -------------------- SESSION STATE --------------------

if "mission_sol" not in st.session_state:
    st.session_state.mission_sol = 1

if "rover_speed" not in st.session_state:
    st.session_state.rover_speed = 1.0

# -------------------- HEADER --------------------

st.markdown("""
# 🔴 MARS-NAV
### MARTIAN MISSION CONTROL SYSTEM

**PLANET:** MARS |
**TARGET REGION:** JEZERO CRATER |
**MODE:** EXPLORATION / RESEARCH PROTOTYPE
""")

st.divider()

# -------------------- SIDEBAR --------------------

st.sidebar.markdown("# 🔴 MARS-NAV")
st.sidebar.caption("MISSION CONTROL TERMINAL")

page = st.sidebar.radio(
    "SYSTEM NAVIGATION",
    [
        "Mission Overview",
        "Mars Surface Map",
        "3D Jezero Terrain",
        "Rover Route Planner",
        "Terrain Analysis",
        "Survival Planner",
        "Scientific Data"
    ]
)

st.sidebar.divider()
st.sidebar.markdown("### MISSION SETTINGS")

st.session_state.mission_sol = st.sidebar.number_input(
    "Mission Sol",
    min_value=1,
    max_value=1000,
    value=int(st.session_state.mission_sol)
)

st.session_state.rover_speed = st.sidebar.slider(
    "Rover speed (km/hour)",
    min_value=0.1,
    max_value=5.0,
    value=float(st.session_state.rover_speed),
    step=0.1
)

st.sidebar.divider()
st.sidebar.caption("MARS-NAV | DEVELOPMENT VERSION 2.0")

# -------------------- SHARED FUNCTIONS --------------------

def mars_distance(lat1, lon1, lat2, lon2):
    """Calculate approximate surface distance on Mars."""
    lat1, lon1, lat2, lon2 = map(
        np.radians, [lat1, lon1, lat2, lon2]
    )

    dlat = lat2 - lat1
    dlon = lon2 - lon1

    a = (
        np.sin(dlat / 2) ** 2
        + np.cos(lat1) * np.cos(lat2)
        * np.sin(dlon / 2) ** 2
    )

    return 2 * MARS_RADIUS_KM * np.arcsin(np.sqrt(a))


def create_map():
    """Create a Jezero regional map using NASA MOLA colour-relief tiles."""

    mars_map = folium.Map(
        location=[JEZERO_LAT, JEZERO_LON],
        zoom_start=2,
        tiles=None,
        control_scale=True,
        width="100%",
        height=800
    )

    # NASA MOLA global colour-relief basemap
    folium.TileLayer(
        tiles=(
            "https://s3-eu-west-1.amazonaws.com/"
            "whereonmars.cartodb.net/"
            "mola_color-noshade_global/{z}/{x}/{y}.png"
        ),
        attr="NASA MOLA global colour relief",
        name="NASA MOLA Terrain",
        overlay=False,
        control=True,
        max_zoom=5,
        min_zoom=0,
        no_wrap=True
    ).add_to(mars_map)

    # Jezero Crater centre
    folium.Marker(
        location=[JEZERO_LAT, JEZERO_LON],
        tooltip="Jezero Crater — Mission Centre",
        popup="Jezero Crater",
        icon=folium.Icon(
            color="red",
            icon="info-sign"
        )
    ).add_to(mars_map)

    folium.LayerControl().add_to(mars_map)

    return mars_map


    folium.TileLayer(
        tiles=(
            "https://s3-eu-west-1.amazonaws.com/"
            "whereonmars.cartodb.net/"
            "mola_color-noshade_global/"
            "{z}/{x}/{y}.png"
        ),
        attr="Mars MOLA global colour relief",
        name="MOLA Colour Relief",
        overlay=False,
        control=True
    ).add_to(mars_map)

    folium.Marker(
        [JEZERO_LAT, JEZERO_LON],
        tooltip="Jezero Crater reference point",
        popup="Approximate Jezero Crater reference location",
        icon=folium.Icon(color="red", icon="info-sign")
    ).add_to(mars_map)

    for name, coordinates in LANDMARKS.items():
        folium.CircleMarker(
            location=coordinates,
            radius=5,
            color="#ffb36b",
            fill=True,
            fill_opacity=0.8,
            tooltip=name
        ).add_to(mars_map)

    folium.LayerControl().add_to(mars_map)

    return mars_map



def load_elevation_data(uploaded_file):
    """Read and downsample a real Mars elevation GeoTIFF."""
    try:
        import rasterio
        from rasterio.io import MemoryFile
        from rasterio.enums import Resampling
        import numpy as np

        content = uploaded_file.getvalue()

        with MemoryFile(content) as memfile:
            with memfile.open() as dataset:

                if dataset.count < 1:
                    st.error("The GeoTIFF contains no elevation band.")
                    return None

                original_height = dataset.height
                original_width = dataset.width

                # Keep the original aspect ratio.
                scale = min(
                    1.0,
                    350 / max(original_height, original_width)
                )

                
            new_height = max(2, int(original_height * scale))
            new_width = max(2, int(original_width * scale))

            st.write("Original dimensions:", original_height, original_width)
            st.write("Resized dimensions:", new_height, new_width)

            # Read actual elevation values
            elevation = dataset.read(
    1,
             out_shape=(new_height, new_width),
            masked=True,
            resampling=Resampling.average
)
   
            elevation = np.ma.filled(
                elevation.astype("float32"),
                np.nan
            )

            # Reject files without usable elevation data.
            if not np.isfinite(elevation).any():
                st.error("No valid elevation values were found.")
                return None
            st.write("Minimum elevation:", float(np.nanmin(elevation)))
            st.write("Maximum elevation:", float(np.nanmax(elevation)))
            st.write("Average elevation:", float(np.nanmean(elevation)))

            # Adjust pixel spacing for the resized raster.
            transform = dataset.transform * dataset.transform.scale(
            original_width / new_width,
            original_height / new_height
)

            st.write("Pixel width:", abs(transform.a))
            st.write("Pixel height:", abs(transform.e))

            return {
                "elevation": elevation,
                "crs": str(dataset.crs),
                "transform": transform,
                "bounds": dataset.bounds,
                "original_shape": (original_height, original_width),
                "pixel_width": abs(transform.a),
                "pixel_height": abs(transform.e),
                "nodata": dataset.nodata
            }

    except Exception as error:
        st.error(f"Could not read elevation GeoTIFF: {error}")
        return None



def display_3d_terrain(elevation_data):
    """Display a rotatable 3D elevation surface."""

    z = elevation_data["elevation"]

    rows, cols = z.shape

    pixel_width = elevation_data["pixel_width"]
    pixel_height = elevation_data["pixel_height"]

    x = np.arange(cols) * pixel_width
    y = np.arange(rows) * pixel_height

    fig = go.Figure(
    data=[
        go.Surface(
            x=x,
            y=y,
            z=z,
            colorscale=[
                [0.0, "#3b1f16"],
                [0.2, "#8d3f24"],
                [0.4, "#c66b32"],
                [0.6, "#e69a50"],
                [0.8, "#f2c078"],
                [1.0, "#fff0a2"]
            ],
            colorbar=dict(
                title="Elevation",
                tickfont=dict(color="white")
            ),
            hovertemplate=(
                "X: %{x}<br>"
                "Y: %{y}<br>"
                "Elevation: %{z:.2f}"
                "<extra>Elevation dataset</extra>"
            )
        )
    ]
)

    fig.update_layout(
        title="JEZERO CRATER | 3D ELEVATION MODEL",
        height=850,
        paper_bgcolor="#17100e",
        plot_bgcolor="#17100e",
        font=dict(color="white"),
        scene=dict(
         xaxis_title="East-West Distance (m)",
         yaxis_title="North-South Distance (m)",
         zaxis_title="Elevation (m)", 
         aspectmode="data",
         bgcolor="#17100e"

        ),
        margin=dict(l=20, r=20, t=60, b=20),
autosize=True,
    )

    st.plotly_chart(fig, width="stretch")


# ============================================================
# PAGE 1 | MISSION OVERVIEW
# ============================================================

if page == "Mission Overview":

    st.markdown("## 🚀 MISSION OVERVIEW")

    st.write(
        "MARS-NAV is an interactive Martian exploration "
        "prototype focused on the Jezero Crater region."
    )

    c1, c2, c3, c4 = st.columns(4)

    c1.metric("Mission Sol", st.session_state.mission_sol)
    c2.metric("Target Planet", "Mars")
    c3.metric("Rover Speed", f"{st.session_state.rover_speed:.1f} km/h")
    c4.metric("Target Region", "Jezero")

    st.divider()

    st.markdown("### Mission Objectives")

    a, b = st.columns(2)

    with a:
        st.markdown("""
        **1. Surface Exploration**
        - Explore Martian surface maps.
        - Locate important terrain features.
        - Understand elevation differences.

        **2. Rover Navigation**
        - Plan rover routes.
        - Compare alternative paths.
        - Estimate travel distance.
        """)

    with b:
        st.markdown("""
        **3. Terrain Intelligence**
        - Visualize elevation data.
        - Identify steep terrain.
        - Understand potential hazards.

        **4. Survival Planning**
        - Estimate resource requirements.
        - Plan water and oxygen supplies.
        - Evaluate mission duration.
        """)

    st.info(
        "This is a research and educational prototype. "
        "It is not an operational spacecraft navigation system."
    )


# ============================================================
# PAGE 2 | MARS SURFACE MAP
# ============================================================

elif page == "Mars Surface Map":

    st.markdown("## 🌍 GLOBAL MARS EXPLORER")

    st.write(
        "Explore the Jezero region using the available "
        "MOLA colour-relief map."
    )

    mars_map = create_map()

    st_folium(
        mars_map,
        height=600,
        use_container_width=True
    )

    st.caption(
        "Map source: Mars MOLA colour-relief tile service. "
        "This is a visual basemap, not a high-resolution "
        "rover-safe navigation map."
    )


# ============================================================
# PAGE 3 | 3D JEZERO TERRAIN
# ============================================================

elif page == "3D Jezero Terrain":

    st.markdown("## 🏔️ 3D JEZERO CRATER TERRAIN")

    st.write(
        "Upload a real Mars elevation GeoTIFF to generate "
        "a rotatable 3D terrain surface."
    )

    st.info(
        "Supported input: single-band elevation GeoTIFF "
        "containing numeric elevation values. "
        "A coloured image or screenshot is not an elevation dataset."
    )

    uploaded_dem = st.file_uploader(
        "Upload Mars elevation GeoTIFF",
        type=["tif", "tiff"],
        key="terrain_upload"
    )

    if uploaded_dem is not None:

        with st.spinner("Reading elevation data..."):
            elevation_data = load_elevation_data(uploaded_dem)

        if elevation_data is not None:

            st.success("Elevation raster loaded.")

            st.write(
                f"Coordinate reference system: "
                f"{elevation_data['crs']}"
            )

            z = elevation_data["elevation"]

            valid = z[np.isfinite(z)]

            if len(valid) > 0:

                col1, col2, col3 = st.columns(3)

                col1.metric(
                    "Minimum elevation",
                    f"{np.min(valid):.2f}"
                )

                col2.metric(
                    "Maximum elevation",
                    f"{np.max(valid):.2f}"
                )

                col3.metric(
                    "Elevation range",
                    f"{np.max(valid) - np.min(valid):.2f}"
                )

                display_3d_terrain(elevation_data)

                st.caption(
                    "The displayed elevation values come from "
                    "the uploaded raster. Check its metadata and "
                    "vertical units before interpreting them."
                )

            else:
                st.error("The raster contains no valid elevation values.")

    else:

        st.warning(
            "No elevation GeoTIFF uploaded yet. "
            "The 3D terrain viewer will appear after a valid "
            "elevation dataset is uploaded."
        )

        st.markdown("### What the 3D model will show")

        st.markdown("""
        - Crater rim and basin elevation.
        - Surface slopes and relief.
        - Terrain variation.
        - A rotatable and zoomable 3D surface.
        """)


# ============================================================
# PAGE 4 | ROVER ROUTE PLANNER
# ============================================================

elif page == "Rover Route Planner":

    st.markdown("## 🤖 ROVER ROUTE PLANNER")

    st.write(
        "Compare a direct route with an illustrative "
        "detour around a potential hazard."
    )

    st.warning(
        "The routes below are simulated examples. "
        "They are not actual Perseverance rover paths."
    )

    col1, col2 = st.columns(2)

    with col1:
        start_name = st.selectbox(
            "Starting location",
            list(LANDMARKS.keys()),
            index=0
        )

    with col2:
        destination_name = st.selectbox(
            "Destination",
            list(LANDMARKS.keys()),
            index=1
        )

    start = LANDMARKS[start_name]
    destination = LANDMARKS[destination_name]

    direct_distance = mars_distance(
        start[0], start[1],
        destination[0], destination[1]
    )

    detour_distance = direct_distance * 1.25

    travel_hours = (
        detour_distance /
        max(st.session_state.rover_speed, 0.1)
    )

    c1, c2, c3 = st.columns(3)

    c1.metric(
        "Direct route",
        f"{direct_distance:.2f} km"
    )

    c2.metric(
        "Illustrative detour",
        f"{detour_distance:.2f} km"
    )

    c3.metric(
        "Estimated travel time",
        f"{travel_hours:.2f} hours"
    )

    st.markdown("### Route visualization")

    fig = go.Figure()

    fig.add_trace(
        go.Scatter(
            x=[start[1], destination[1]],
            y=[start[0], destination[0]],
            mode="lines+markers",
            name="Direct route",
            line=dict(color="#ff5252", width=4)
        )
    )

    midpoint_lon = (start[1] + destination[1]) / 2
    midpoint_lat = (start[0] + destination[0]) / 2

    detour_lon = midpoint_lon + 0.04
    detour_lat = midpoint_lat + 0.03

    fig.add_trace(
        go.Scatter(
            x=[
                start[1],
                detour_lon,
                destination[1]
            ],
            y=[
                start[0],
                detour_lat,
                destination[0]
            ],
            mode="lines+markers",
            name="Illustrative detour",
            line=dict(color="#43c9ff", width=4)
        )
    )

    fig.update_layout(
        height=500,
        title="ROVER ROUTE COMPARISON",
        xaxis_title="Longitude (degrees)",
        yaxis_title="Latitude (degrees)",
        paper_bgcolor="#17100e",
        plot_bgcolor="#241713",
        font=dict(color="white")
    )

    st.plotly_chart(fig, use_container_width=True)

    st.info(
        "A real terrain-aware planner must calculate slope, "
        "surface hazards and traversability from elevation "
        "and imagery data."
    )


# ============================================================
# PAGE 5 | TERRAIN ANALYSIS
# ============================================================

elif page == "Terrain Analysis":

    st.markdown("## 🏔️ TERRAIN ANALYSIS")

    st.write(
        "Understand the measurements required to assess "
        "Martian surface safety."
    )

    st.markdown("### Important terrain parameters")

    terrain_table = pd.DataFrame({
        "Parameter": [
            "Elevation",
            "Slope",
            "Surface roughness",
            "Crater proximity",
            "Obstacle density"
        ],
        "Purpose": [
            "Understand height differences",
            "Identify steep terrain",
            "Estimate surface irregularity",
            "Identify nearby depressions",
            "Estimate route difficulty"
        ],
        "Importance": [
            "High",
            "High",
            "High",
            "Medium",
            "High"
        ]
    })

    st.dataframe(
        terrain_table,
        use_container_width=True,
        hide_index=True
    )

    st.markdown("### Elevation data upload")

    terrain_file = st.file_uploader(
        "Upload elevation GeoTIFF for analysis",
        type=["tif", "tiff"],
        key="analysis_upload"
    )

    if terrain_file is not None:

        data = load_elevation_data(terrain_file)

        if data is not None:

            z = data["elevation"]

            valid = z[np.isfinite(z)]

            if len(valid) > 0:

                st.metric(
                    "Elevation range",
                    f"{np.max(valid) - np.min(valid):.2f}"
                )

                st.metric(
                    "Mean elevation",
                    f"{np.mean(valid):.2f}"
                )

                fig = go.Figure(
                    data=go.Heatmap(
                        z=z,
                        colorscale="Earth",
                        colorbar=dict(title="Elevation")
                    )
                )

                fig.update_layout(
                    title="Elevation distribution",
                    height=500,
                    paper_bgcolor="#17100e",
                    font=dict(color="white")
                )

                st.plotly_chart(
                    fig,
                    use_container_width=True
                )


# ============================================================
# PAGE 6 | SURVIVAL PLANNER
# ============================================================

elif page == "Survival Planner":

    st.markdown("## 🧑‍🚀 MISSION SURVIVAL PLANNER")

    st.write(
        "Estimate basic supplies for a hypothetical "
        "Martian surface mission."
    )

    col1, col2 = st.columns(2)

    with col1:
        crew = st.number_input(
            "Crew members",
            min_value=1,
            max_value=12,
            value=2
        )

        duration = st.number_input(
            "Mission duration (days)",
            min_value=1,
            max_value=1000,
            value=30
        )

    with col2:
        water_per_person = st.number_input(
            "Water requirement per person (litres/day)",
            min_value=1.0,
            max_value=20.0,
            value=3.0
        )

        oxygen_per_person = st.number_input(
            "Oxygen requirement per person (kg/day)",
            min_value=0.1,
            max_value=5.0,
            value=0.84
        )

    total_water = crew * duration * water_per_person
    total_oxygen = crew * duration * oxygen_per_person

    st.divider()

    a, b = st.columns(2)

    a.metric(
        "Estimated water",
        f"{total_water:,.1f} litres"
    )

    b.metric(
        "Estimated oxygen",
        f"{total_oxygen:,.1f} kg"
    )

    st.caption(
        "Simplified planning estimates only. "
        "Actual mission requirements depend on recycling, "
        "habitat systems, crew activity and mission design."
    )


# ============================================================
# PAGE 7 | SCIENTIFIC DATA
# ============================================================

elif page == "Scientific Data":

    st.markdown("## 🔬 SCIENTIFIC DATA")

    st.write(
        "Reference information and data requirements "
        "for the MARS-NAV project."
    )

    st.markdown("### Target region")

    st.markdown("""
    **Jezero Crater**

    - Planet: Mars
    - Approximate reference latitude: 18.44° N
    - Approximate reference longitude: 77.73° E
    - Exploration mission: NASA Perseverance rover
    """)

    st.markdown("### Data types required")

    data_table = pd.DataFrame({
        "Dataset": [
            "MOLA",
            "HiRISE",
            "CTX",
            "HRSC"
        ],
        "Data type": [
            "Global elevation",
            "High-resolution images and terrain products",
            "Regional surface images",
            "Topography and stereo imagery"
        ],
        "Potential use": [
            "Large-scale elevation context",
            "Detailed local terrain analysis",
            "Regional mapping",
            "Regional elevation models"
        ]
    })

    st.dataframe(
        data_table,
        use_container_width=True,
        hide_index=True
    )

    st.markdown("### Data quality principles")

    st.markdown("""
    - Record the original data source.
    - Record the dataset resolution.
    - Preserve coordinate reference information.
    - Check elevation units and no-data values.
    - Distinguish measured data from simulations.
    """)

    st.info(
        "A global MOLA dataset may not provide enough "
        "detail for safe rover-scale route planning. "
        "Higher-resolution terrain data is needed."
    )


# ============================================================
# FOOTER
# ============================================================

st.divider()

st.markdown("""
<div style="text-align:center; color:#d68b6a;">
    MARS-NAV | MARTIAN EXPLORATION SYSTEM |
    DEVELOPMENT VERSION 2.0
</div>
""", unsafe_allow_html=True)

# ================= MARS-NAV 3D MARS VIEWER =================

import streamlit.components.v1 as components
from pathlib import Path

st.markdown("## 🌍 Interactive 3D Mars Explorer")

viewer_path = Path(__file__).parent / "mars_viewer.html"

if viewer_path.exists():
    viewer_html = viewer_path.read_text(encoding="utf-8")
    cesium_token = st.secrets["CESIUM_ION_TOKEN"]

    viewer_html = viewer_html.replace(
    "TOKEN_PLACEHOLDER",
    cesium_token
)

if viewer_path.exists():
    viewer_html = viewer_path.read_text(encoding="utf-8")
    cesium_token = st.secrets["CESIUM_ION_TOKEN"]

    viewer_html = viewer_html.replace(
        "TOKEN_PLACEHOLDER",
        cesium_token
    )

    components.html(viewer_html, height=700, scrolling=False)

else:
    st.error("mars_viewer.html was not found.")

    components.html(viewer_html, height=700, scrolling=False)



    # 3D JEZERO CRATER TERRAIN
st.header("🪐 3D Jezero Crater Terrain")

import rasterio
import numpy as np
import plotly.graph_objects as go
from pathlib import Path

terrain_files = list(Path("data").glob("*DTM*.tif"))

if terrain_files:
    with rasterio.open(terrain_files[0]) as src:
        elevation = src.read(1, out_shape=(1, 500, 500))
        elevation = elevation.astype(float)

        elevation[elevation == src.nodata] = np.nan

    fig = go.Figure(data=[
        go.Surface(
    z=elevation,
    colorscale=[
        [0.0, "#3b2418"],
        [0.25, "#75452c"],
        [0.50, "#b87950"],
        [0.75, "#d99b68"],
        [1.0, "#f2d2a0"]
    ]
)
    ])

    scene=dict(
    xaxis_title="East-West",
    yaxis_title="North-South",
    zaxis_title="Elevation",
    aspectmode="manual",
    aspectratio=dict(x=1, y=1, z=0.35)
)

    st.plotly_chart(fig, use_container_width=True)

else:
    st.warning("No DTM GeoTIFF found in the data folder.")


st.markdown("### Interactive 3D Jezero Terrain")

if "show_jezero_3d" not in st.session_state:
    st.session_state.show_jezero_3d = False

if st.button("Load Interactive 3D Jezero Terrain"):
    st.session_state.show_jezero_3d = True

if st.session_state.show_jezero_3d:
    try:
        with open("jezero_3d.html", "r", encoding="utf-8") as file:
            terrain_html = file.read()

        components.html(
            terrain_html,
            height=650,
            scrolling=False
        )

    except FileNotFoundError:
        st.warning("Jezero 3D terrain file not found. Run prepare_jezero.py first.")
else:
    st.caption("Click the button above to load the interactive terrain.")


# ============================================================
# MARS-NAV ROVER ROUTE PLANNER
# ============================================================

import heapq
import math
from pathlib import Path
import numpy as np
import rasterio
import plotly.graph_objects as go

st.markdown("---")
st.markdown("## MARS-NAV | Rover Route Planner")
st.caption("Terrain-aware route planning using the Jezero Crater elevation model.")

# Find the Jezero CTX DEM
dem_candidates = list(Path("data").glob("*CTXDEM*.tif"))

if not dem_candidates:
    st.error("Jezero CTX DEM not found in the data folder.")
else:
    dem_path = dem_candidates[0]

    slope = None
    pixel_size = None

    try:
        elevation, slope, pixel_size = load_rover_terrain(
            str(dem_path),
            stride=20
        )
    except Exception as e:
        st.error(f"Terrain loading failed: {e}")
        st.stop()

        rows, cols = elevation.shape

        st.markdown("### Route configuration")

        col1, col2, col3 = st.columns(3)

        with col1:
            start_row = st.slider(
                "Start row",
                0, rows - 1,
                int(rows * 0.25)
            )

        with col2:
            end_row = st.slider(
                "Destination row",
                0, rows - 1,
                int(rows * 0.75)
            )

        with col3:
            max_allowed_slope = st.slider(
                "Maximum permitted slope (degrees)",
                5, 45, 25
            )

        col4, col5 = st.columns(2)

        with col4:
            start_col = st.slider(
                "Start column",
                0, cols - 1,
                int(cols * 0.20)
            )

        with col5:
            end_col = st.slider(
                "Destination column",
                0, cols - 1,
                int(cols * 0.80)
            )

            found = False
            if st.button("Calculate safest rover route", type="primary"):
                start = (start_row, start_col)
                goal = (end_row, end_col)

            start = (start_row, start_col)
            goal = (end_row, end_col)

            # A* pathfinding
            directions = [
                (-1, 0), (1, 0), (0, -1), (0, 1),
                (-1, -1), (-1, 1), (1, -1), (1, 1)
            ]

            def heuristic(a, b):
                return math.hypot(
                    a[0] - b[0],
                    a[1] - b[1]
                )

            open_set = [(0, start)]
            came_from = {}
            cost_so_far = {start: 0}
            found = False

            while open_set:
                _, current = heapq.heappop(open_set)

                if current == goal:
                    found = True
                    break

                for dr, dc in directions:
                    nr = current[0] + dr
                    nc = current[1] + dc

                    if not (0 <= nr < rows and 0 <= nc < cols):
                        continue

                    if not valid[nr, nc]:
                        continue

                    if slope[nr, nc] > max_allowed_slope:
                        continue

                    step_distance = pixel_size * math.hypot(dr, dc)

                    slope_penalty = 1 + slope[nr, nc] / 15

                    new_cost = (
                        cost_so_far[current]
                        + step_distance * slope_penalty
                    )

                    neighbor = (nr, nc)

                    if new_cost < cost_so_far.get(neighbor, float("inf")):
                        cost_so_far[neighbor] = new_cost
                        came_from[neighbor] = current

                        priority = new_cost + (
                            heuristic(neighbor, goal) * pixel_size
                        )

                        heapq.heappush(
                                open_set,
                                (priority, neighbor)
                            )

            if found:
                # Reconstruct the safest rover route
                path = [goal]

                while path[-1] != start:
                    previous = came_from.get(path[-1])

                    if previous is None:
                        break

                    path.append(previous)

                path.reverse()

                if path and path[0] == start and path[-1] == goal:
                    path_rows = [point[0] for point in path]
                    path_cols = [point[1] for point in path]

                    # Calculate route distance
                    route_distance = sum(
                        pixel_size * math.hypot(
                            path_rows[i + 1] - path_rows[i],
                            path_cols[i + 1] - path_cols[i]
                        )
                        for i in range(len(path) - 1)
                    )

                    # Calculate elevation profile
                    route_elevations = np.array([
                        elevation[r, c] for r, c in path
                    ])

                    elevation_gain = float(
                        np.maximum(np.diff(route_elevations), 0).sum()
                    )

                    maximum_route_slope = max(
                        (float(slope[r, c]) for r, c in path),
                        default=0.0
                    )

                    # Build route chart
                    route_fig = go.Figure()

                    route_fig.add_trace(
                        go.Scatter(
                            x=path_cols,
                            y=path_rows,
                            mode="lines+markers",
                            name="A* Rover Route",
                            line=dict(color="#00E5FF", width=4),
                            marker=dict(size=4, color="#FF5252")
                        )
                    )

                    route_fig.add_trace(
                        go.Scatter(
                            x=[start[1], goal[1]],
                            y=[start[0], goal[0]],
                            mode="markers",
                            name="Start / Destination",
                            marker=dict(
                                size=12,
                                color=["#00FF88", "#FF5252"]
                            )
                        )
                    )

                    route_fig.update_layout(
                        title="MARS-NAV | Terrain-Aware A* Rover Route",
                        template="plotly_dark",
                        xaxis_title="DEM Column",
                        yaxis_title="DEM Row",
                        height=550,
                        paper_bgcolor="#17100E",
                        plot_bgcolor="#241713",
                        font=dict(color="white")
                    )

                    st.plotly_chart(
                        route_fig,
                        use_container_width=True
                    )

                    # Display route measurements
                    m1, m2, m3 = st.columns(3)

                    m1.metric(
                        "Route distance",
                        f"{route_distance / 1000:.2f} km"
                    )

                    m2.metric(
                        "Elevation gain",
                        f"{elevation_gain:.1f} m"
                    )

                    m3.metric(
                        "Maximum route slope",
                        f"{maximum_route_slope:.1f}°"
                    )

                    # Display elevation heatmap and route
                    fig_route = go.Figure()

                    fig_route.add_trace(
                        go.Heatmap(
                            z=elevation,
                            colorscale="Turbo",
                            colorbar=dict(title="Elevation (m)"),
                            hoverinfo="skip"
                        )
                    )

                    fig_route.add_trace(
                        go.Scatter(
                            x=path_cols,
                            y=path_rows,
                            mode="lines",
                            name="Rover Route",
                            line=dict(color="white", width=3)
                        )
                    )

                    fig_route.update_layout(
                        title="Jezero Crater | Rover Route on Elevation Map",
                        template="plotly_dark",
                        xaxis_title="DEM Column",
                        yaxis_title="DEM Row",
                        height=550
                    )

                    st.plotly_chart(
                        fig_route,
                        use_container_width=True
                    )

                    st.success("A rover route was successfully calculated.")

                else:
                    st.warning(
                        "The route could not be reconstructed. "
                        "Please select different endpoints."
                    )

            else:
                st.warning(
                    "No safe route found. Try increasing the permitted "
                    "slope or selecting different endpoints."
                )

